<?php

$host = "localhost";
$user = "root";
$passwd = "";
$db = "christ";

$con = new mysqli($host, $user, $passwd, $db);

if ($con->connect_errno) {

    printf("connection failed: %s\n", $con->connect_error());
    exit();
}
$id =filter_input(INPUT_POST, 'id');

$query = "DELETE FROM stuinfo (stu_id,stu_name, age, gender, course, address) WHERE stu_id= '$id'";
if ($con->query($query)){
    echo "Record is deleted sucessfully";
    }
    else{
    echo "Error: ". $query ."
    ". $con->error;
    }
    $con->close();

