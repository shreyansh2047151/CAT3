<?php

$host = "localhost";
$user = "root";
$passwd = "";
$db = "christ";

$con = new mysqli($host, $user, $passwd, $db);

if ($con->connect_errno) {

    printf("connection failed: %s\n", $con->connect_error());
    exit();
}
$yourName= filter_input(INPUT_POST, 'name');
$yourAge= filter_input(INPUT_POST, 'age');
$yourGender= filter_input(INPUT_POST, 'gender');
$yourCourse= filter_input(INPUT_POST, 'course');
$Address= filter_input(INPUT_POST, 'address');
$query = "INSERT INTO stuinfo (stu_name, age, gender, course, address) VALUES ('$yourName','$yourAge', '$yourGender', '$yourCourse','$Address')";
if ($con->query($query)){
    echo "New record is inserted sucessfully";
    }
    else{
    echo "Error: ". $query ."
    ". $con->error;
    }
    $con->close();

